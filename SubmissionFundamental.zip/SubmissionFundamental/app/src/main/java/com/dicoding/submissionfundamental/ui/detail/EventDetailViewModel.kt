package com.dicoding.submissionfundamental.ui.detail

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.JsonObject
import data.response.ListEventsItem
import data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EventDetailViewModel : ViewModel() {

    private val _eventDetail = MutableLiveData<ListEventsItem?>()
    val eventDetail: LiveData<ListEventsItem?> = _eventDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun getEventDetail(eventId: Int) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getEventDetail(eventId)
        client.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val jsonObject = response.body()
                    if (jsonObject != null && jsonObject.has("event")) {
                        val eventJson = jsonObject.getAsJsonObject("event")
                        val event = Gson().fromJson(eventJson, ListEventsItem::class.java)
                        Log.d("EventDetailViewModel", "Parsed event: $event")
                        _eventDetail.postValue(event)
                    } else {
                        Log.e("EventDetailViewModel", "Response body is null or doesn't contain 'event'")
                        _eventDetail.postValue(null)
                    }
                } else {
                    Log.e("EventDetailViewModel", "Response not successful. Code: ${response.code()}")
                    _eventDetail.postValue(null)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("EventDetailViewModel", "Call failed", t)
                _eventDetail.postValue(null)
            }
        })
    }
}